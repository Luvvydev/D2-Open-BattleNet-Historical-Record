# Beyond the Realm | Offline Research Notes

These are original summaries, selected historical numerical facts, and links to original authors. They are not verbatim copies of the full third-party guides.

## Evidence protocol
- **Documented:** a surviving file, forum post, or contemporary email says it.
- **Recollected:** firsthand testimony supplied by Azreal]AMF[/HU_Thor, which might not be independently corroborated.
- **Interpretation:** historical synthesis or mechanics hypothesis.
- Historical descriptions of mechanics are not proof the engine behaves identically in every patch.

## Source index
- House of Legends Diablo II Hacking: https://houseoflegends.forumotion.com/f33-diablo-ii-hacking

## Telekinesis Values
Source: https://houseoflegends.forumotion.com/t59-telekinesis-values
Credit: Sheriff; credits DBD_TaN

Telekinesis changes the mana cost of Energy Shield. The guide preserves a full value table and a second layer of peculiar good and bad ranges, including the notorious exact mana thresholds.

### Selected data
- 0 TK: 2.0000 mana spent per damage absorbed
- 12 TK: 1.2500 mana spent per damage absorbed
- 16 TK: 1.0000 mana spent per damage absorbed
- 24 TK: 0.5000 mana spent per damage absorbed
- 30 TK: 0.1250 mana spent per damage absorbed
- 31 to 99 TK: 0.0625 mana spent per damage absorbed

### Research interpretation
- Ratio described by the guide: 2 − 0.0625 × TK, down to a minimum of 0.0625 at TK 31.
- The author documents 1,048,576 mana at TK 30 as one of the specific “funky mana” points.
- For TK 31 through 99, the guide lists alternating windows with boundaries at multiples of 524,288, up to 8,388,608.

This surviving account aligns with the scene’s obsession with exact life-lock figures and explains why seemingly tiny changes could break a build. The full historical table remains on the source page.

## Physical Immunity & Mana Values
Source: https://houseoflegends.forumotion.com/t63-physical-immunity-mana-values
Credit: Sheriff; credits named historical contributors

An extended account of what duelers called physical immunity and “funky” mana. It does not treat immunity as a simple maximum-stat trick: Telekinesis ratios, damage routing and precise boundaries matter.

### Selected data
- 1,048,576: A prominent historical TK 30 mana breakpoint
- 8,388,608: A recurring upper boundary in the described calculations
- Join order: A reported variable affecting interactions
- Monster attacks: Some effects reportedly bypassed the Energy Shield route

### Research interpretation
- A guide example connects 25,600 base mana and +3,996% maximum mana with 1,048,576 displayed mana.
- The research distinguishes ordinary Energy Shield hits from direct mana-altering effects.

This is the closest surviving technical parallel to the accounts of life lock and the later mosquito-based counter. That specific personal counter remains an oral recollection, not a claim made by this guide.

## Life Values & Regeneration
Source: https://houseoflegends.forumotion.com/t62-life-values-regeneration
Credit: Sheriff; credits ToXiC

A guide to enormous life pools, Prayer auras, Oak Sage, resistances, absorption, and the surprising idea that too much healing can itself become lethal.

### Selected data
- 4,194,303: Described as a lower-life configuration less prone to overheal
- 6 to 7.8 million: Typical high-life range discussed
- Up to ~8.05 million: High-life possibility under stated conditions
- ~5,000 Prayer: An example of stacked total aura levels, not a guaranteed effective level

### Research interpretation
- Prayer heal formula given by the guide: (skill level − 28) × 3 + 41.
- Prayer mana-drain formula given by the guide: (skill level − 28) × 0.376 + 6.
- The author stresses that active aura-source count matters in addition to displayed skill level.

The overhealing discussion supplies independent context for the remembered HU-era Life Tap experiment. It cannot establish the exact cause of those historical duel deaths.

## Attack Speed, Damage & Defence
Source: https://houseoflegends.forumotion.com/t61-attack-speed-damages-and-defence
Credit: Sheriff; credits Set

A dense technical record of how smite damage, attack timing, negative defense, stun effects, Thorns and repeated aura sources influenced top-end edited-character dueling.

### Selected data
- Skill ID 139: Stun used for the reported stun glitch
- 10% / 90%: Examples of low and high stun-trigger chances
- 8,388,607: A recorded high damage boundary for PvM calculations
- ~714k: Guide discussion of post-reduction Smite / returned-damage ceilings

### Research interpretation
- The author explicitly warns that stronger stun interactions increase returned Thorns damage.
- Thorns-return formula recorded as (level − 1) × 40% + 250%.
- Auras can behave differently as combined levels or multiple active sources.

Matches the remembered effort to lower damage per hit to survive Thorns. The guide documents the general danger; the secret tiny-damage counter is recorded from firsthand testimony.

## Hexing Non-Class Skills
Source: https://houseoflegends.forumotion.com/t60-hexing-non-class-skills
Credit: Sheriff

A practical window into how a normal person could modify a character’s available skills with Hero Editor and basic hexadecimal conversions, without becoming a professional developer.

### Selected data
- Hero Editor: Graphical tool used to inspect and modify saves
- Skill IDs: Converted into hexadecimal values
- Offline files: Characters were edited on personal computers
- Open multiplayer: Changes could then be tested against consenting duelers

### Research interpretation
- The historical guide demonstrates that editing was procedural and teachable, not limited to rare executable-hacking expertise.
- That low barrier to entry made discovery and independent experimentation central to the scene.

Explains why the ecosystem mattered: an approachable editor, permissive online environment, and community-run competition all existed together.

## Oral history crosswalk
- AMF operated private math/calculation forums; character saves traveled via email, MSN, and later Skype.
- The 2006 AMF founder document describes no formal leaders and admission by member vote; period clan claims are not independent ladder tables.
- Life Tap/overhealing war story, the mosquito life-lock counter, Submerge duels, and tiny-damage stun experimentation are firsthand recollections.
- The gem/ear trick involved keeping a single extra item on the cursor through save-and-exit to bypass inventory-space limits.
- The July 3, 2007 email describes Hexon_FF and Hexon_iN as complementary builds, including a weapon-swap effect.
- The surviving Hexon_iN export includes skill properties +63 Submerge and +63 Emerge.

## Historical context and surviving links
- 2024 LadderHall/NightShiver reunion: https://www.reddit.com/r/diablo2/comments/1boysiy/for_the_neckbeards_a_glimpse_into_our_glorious/
- Edited-character reunion: https://www.reddit.com/r/diablo2/comments/lsmm01/anyone_still_do_open_bnet_duels_with_hex_edited/
- AMF archived member list: https://web.archive.org/web/20060831161313/http://z7.invisionfree.com:80/AMF/index.php?act=Members
- Blizzard D2 manual: https://download.blizzard.com/pub/misc/Diablo%20II%20Manual.pdf

## Rights and preservation
Full public forum posts remain credited and linked rather than reproduced without authorization. User-owned character binaries and private emails are not published in this static website.