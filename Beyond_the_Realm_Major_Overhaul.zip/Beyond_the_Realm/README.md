BEYOND THE REALM

Open index.html in a browser. This is an offline website based on my Open Battle.net history, written from my perspective as HU_Thor / Azreal]AMF[.

The original site structure, scripts, research records, and images are preserved. The narrative has been rewritten to match my current GitHub README. The Snowman chapter now names Adeem’s one-hit aura character correctly.

No server, installation, or dependencies needed.
